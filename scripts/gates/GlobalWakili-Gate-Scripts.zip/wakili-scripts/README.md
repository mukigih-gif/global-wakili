# GLOBAL WAKILI — PowerShell Gate Scripts

Place all scripts in: `C:\Projects\global-wakili\scripts\gates\`

---

## STEP 1 — Apply Gate 1 Fixes and Push

```powershell
cd C:\Projects\global-wakili\scripts\gates
.\Gate1-Fixes.ps1
```

This script will:
- Create `docs/governance/` directory
- Replace `prisma db push` with `prisma migrate deploy` in CI
- Create `.env.example` (scans codebase for all process.env vars)
- Move `financedashboard.tsx` from backend to frontend
- Read and triage `startup-error.log`
- Create Gate 2 pending migrations document
- Push branch `gate-1/fixes` to origin

**Every step requires your approval. Nothing is committed automatically.**

---

## STEP 2 — Set Up Claude Code CLI

```powershell
cd C:\Projects\global-wakili\scripts\gates
.\Setup-ClaudeCode.ps1
```

This script will:
- Install Claude Code CLI globally (`npm install -g @anthropic-ai/claude-code`)
- Authenticate with your Anthropic account
- Create `CLAUDE.md` at repo root with full project memory
- Configure Plan Mode (approval required before any file changes)
- Launch Claude Code in the repo

**After this, every Claude Code session automatically knows the full Global Wakili context.**

---

## STEP 3 — Run Gates

```powershell
# Check status of all 16 gates
.\Run-Gate.ps1 -Status

# Preview Gate 2 without making any changes
.\Run-Gate.ps1 -Gate 2 -DryRun

# Run Gate 2 (requires Gate 1 to be COMPLETE)
.\Run-Gate.ps1 -Gate 2
```

### Gate ordering is enforced
The script will refuse to run Gate N if Gate N-1 is not marked COMPLETE.

### Every deliverable requires approval
Each gate deliverable shows:
- What changes
- Which files are affected
- Risk level
- Test plan

You type YES / NO / ABORT for each one.

---

## Gate Status File

Gate completion status is stored in:
`docs/governance/GATE_STATUS.json`

This file is committed to the repo so the team shares gate state.

---

## Using Claude Code for Gate Work

For deliverables that require deep code changes, use Claude Code directly:

```powershell
cd C:\Projects\global-wakili
claude
```

Claude will read `CLAUDE.md` and know:
- Current gate
- Open workstreams
- Architecture constraints
- Approval requirements

Example prompts for Gate 2:
- "Assess TENANT_SCOPED_MODELS for gaps — plan only, no changes yet"
- "Run the index audit on schema.prisma — show me what's missing"
- "Create the GlobalAuditLog hash unique migration — show me the migration SQL first"

---

## File Structure

```
C:\Projects\global-wakili\
├── CLAUDE.md                          ← Claude Code project memory
├── .env.example                       ← Created by Gate1-Fixes.ps1
├── docs\
│   └── governance\
│       ├── GATE_STATUS.json           ← Gate completion tracking
│       ├── GATE_1_FINAL_ASSESSMENT.md ← Gate 1 report (paste full content here)
│       └── GATE_2_MIGRATIONS_PENDING.md
└── scripts\
    └── gates\
        ├── README.md                  ← This file
        ├── Gate1-Fixes.ps1            ← Gate 1 fixes + push
        ├── Setup-ClaudeCode.ps1       ← Claude Code CLI setup
        ├── Run-Gate.ps1               ← Gate automation master script
        └── Gate2\                     ← Gate 2 deliverable scripts (Claude Code generates these)
```
