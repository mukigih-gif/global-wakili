# ============================================================
# GLOBAL WAKILI — Gate Automation Master Script
# Manages gate transitions with mandatory approval checkpoints.
# Tracks gate status in docs/governance/GATE_STATUS.json
#
# Usage:
#   .\Run-Gate.ps1 -Gate 2          # Run Gate 2
#   .\Run-Gate.ps1 -Gate 2 -DryRun  # Preview Gate 2 without changes
#   .\Run-Gate.ps1 -Status          # Show all gate statuses
# ============================================================

param(
    [int]$Gate = 0,
    [switch]$Status,
    [switch]$DryRun
)

$REPO = "C:\Projects\global-wakili"
$STATUS_FILE = Join-Path $REPO "docs\governance\GATE_STATUS.json"

# ── Helpers ──────────────────────────────────────────────────

function Write-Header($text) {
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  $text" -ForegroundColor Cyan
    Write-Host "================================================================" -ForegroundColor Cyan
}
function Write-OK($text)   { Write-Host "  [OK] $text" -ForegroundColor Green }
function Write-Warn($text) { Write-Host "  [WARN] $text" -ForegroundColor DarkYellow }
function Write-Fail($text) { Write-Host "  [FAIL] $text" -ForegroundColor Red }
function Write-Info($text) { Write-Host "  $text" -ForegroundColor Gray }
function Write-Step($text) { Write-Host "  >> $text" -ForegroundColor Yellow }
function Write-Dry($text)  { Write-Host "  [DRY-RUN] $text" -ForegroundColor DarkCyan }

function Approve($prompt, $default = "NO") {
    if ($DryRun) {
        Write-Dry "Would prompt: $prompt"
        return "DRY"
    }
    Write-Host ""
    Write-Host "  APPROVAL REQUIRED" -ForegroundColor Magenta
    Write-Host "  $prompt" -ForegroundColor White
    Write-Host "  (YES / NO / ABORT): " -ForegroundColor Magenta -NoNewline
    $ans = Read-Host
    return $ans.Trim().ToUpper()
}

# ── Gate Registry ────────────────────────────────────────────

$GATES = @{
    1  = @{ Name = "Repository Assessment";     Branch = "gate-1/fixes";                    Status = "COMPLETE" }
    2  = @{ Name = "Schema Verification";       Branch = "gate-2/schema-verification";      Status = "OPEN" }
    3  = @{ Name = "Tenant Verification";       Branch = "gate-3/tenant-verification";      Status = "LOCKED" }
    4  = @{ Name = "Finance Verification";      Branch = "gate-4/finance-verification";     Status = "LOCKED" }
    5  = @{ Name = "Trust Verification";        Branch = "gate-5/trust-verification";       Status = "LOCKED" }
    6  = @{ Name = "Security Verification";     Branch = "gate-6/security-verification";    Status = "LOCKED" }
    7  = @{ Name = "Control Plane Closure";     Branch = "gate-7/control-plane";            Status = "LOCKED" }
    8  = @{ Name = "Notification Closure";      Branch = "gate-8/notifications";            Status = "LOCKED" }
    9  = @{ Name = "Document Platform Closure"; Branch = "gate-9/documents";                Status = "LOCKED" }
    10 = @{ Name = "AI Platform Closure";       Branch = "gate-10/ai-platform";             Status = "LOCKED" }
    11 = @{ Name = "External Integrations";     Branch = "gate-11/integrations";            Status = "LOCKED" }
    12 = @{ Name = "Frontend Completion";       Branch = "gate-12/frontend";                Status = "LOCKED" }
    13 = @{ Name = "Testing Matrix";            Branch = "gate-13/testing";                 Status = "LOCKED" }
    14 = @{ Name = "Documentation";             Branch = "gate-14/documentation";           Status = "LOCKED" }
    15 = @{ Name = "Production Readiness";      Branch = "gate-15/production-readiness";    Status = "LOCKED" }
    16 = @{ Name = "Go-Live Review";            Branch = "gate-16/go-live";                 Status = "LOCKED" }
}

# ── Gate Deliverables ────────────────────────────────────────

$GATE_DELIVERABLES = @{
    2 = @(
        @{ ID = "D-01"; Title = "CI: prisma migrate deploy (not db push)";         Risk = "CRITICAL"; Script = "Gate2\D01-CI-Migration-Strategy.ps1" }
        @{ ID = "D-02"; Title = "GlobalAuditLog.hash @unique migration";           Risk = "HIGH";     Script = "Gate2\D02-GlobalAuditLog-Hash-Unique.ps1" }
        @{ ID = "D-03"; Title = "AuditLog sequenceNumber migration";               Risk = "HIGH";     Script = "Gate2\D03-Audit-Sequence-Number.ps1" }
        @{ ID = "D-04"; Title = "TENANT_SCOPED_MODELS gap resolution";             Risk = "HIGH";     Script = "Gate2\D04-Tenant-Scoped-Models.ps1" }
        @{ ID = "D-05"; Title = "Index audit and missing indexes";                 Risk = "MEDIUM";   Script = "Gate2\D05-Index-Audit.ps1" }
        @{ ID = "D-06"; Title = "Orphaned model assessment";                       Risk = "MEDIUM";   Script = "Gate2\D06-Orphaned-Models.ps1" }
        @{ ID = "D-07"; Title = ".env.example complete";                           Risk = "HIGH";     Script = "Gate2\D07-Env-Example.ps1" }
        @{ ID = "D-08"; Title = "Gate 2 report committed to docs/governance/";     Risk = "LOW";      Script = "Gate2\D08-Gate2-Report.ps1" }
    )
    3 = @(
        @{ ID = "D-01"; Title = "Resolve 278 'any' types in tenant-scoped paths";  Risk = "HIGH";     Script = "Gate3\D01-Any-Types.ps1" }
        @{ ID = "D-02"; Title = "Fix TimerDbClient = any";                         Risk = "HIGH";     Script = "Gate3\D02-TimerDbClient.ps1" }
        @{ ID = "D-03"; Title = "Cross-tenant breach test matrix";                 Risk = "CRITICAL"; Script = "Gate3\D03-Breach-Tests.ps1" }
        @{ ID = "D-04"; Title = "Session model tenant scoping decision";           Risk = "HIGH";     Script = "Gate3\D04-Session-Tenancy.ps1" }
        @{ ID = "D-05"; Title = "Realtime socket tenant namespacing";              Risk = "MEDIUM";   Script = "Gate3\D05-Socket-Tenancy.ps1" }
    )
}

# ── Load / Save Gate Status ──────────────────────────────────

function Load-GateStatus {
    if (Test-Path $STATUS_FILE) {
        try {
            $raw = Get-Content $STATUS_FILE -Raw
            return $raw | ConvertFrom-Json -AsHashtable
        } catch {
            return @{}
        }
    }
    return @{}
}

function Save-GateStatus($statusMap) {
    $dir = Split-Path $STATUS_FILE -Parent
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $statusMap | ConvertTo-Json -Depth 5 | Set-Content $STATUS_FILE -Encoding UTF8
}

function Get-GateStatus($gateNum) {
    $stored = Load-GateStatus
    if ($stored.ContainsKey("$gateNum")) {
        return $stored["$gateNum"]
    }
    return $GATES[$gateNum].Status
}

function Set-GateStatus($gateNum, $status, $note = "") {
    $stored = Load-GateStatus
    $stored["$gateNum"] = @{
        status = $status
        updatedAt = (Get-Date -Format 'yyyy-MM-dd HH:mm')
        note = $note
    }
    Save-GateStatus $stored
}

# ── Status Display ───────────────────────────────────────────

function Show-AllGateStatus {
    Write-Header "GLOBAL WAKILI — GATE STATUS BOARD"
    Write-Info "Repo: $REPO"
    Write-Info "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
    Write-Host ""
    Write-Host ("  {0,-6} {1,-35} {2,-12} {3}" -f "Gate", "Name", "Status", "Branch") -ForegroundColor White
    Write-Host "  $('─' * 90)" -ForegroundColor DarkGray

    foreach ($g in 1..16) {
        $gate = $GATES[$g]
        $stored = Load-GateStatus
        $st = if ($stored.ContainsKey("$g")) { $stored["$g"].status } else { $gate.Status }
        $color = switch ($st) {
            "COMPLETE" { "Green" }
            "OPEN"     { "Yellow" }
            "LOCKED"   { "DarkGray" }
            "BLOCKED"  { "Red" }
            default    { "Gray" }
        }
        Write-Host ("  {0,-6} {1,-35} " -f "Gate $g", $gate.Name) -NoNewline -ForegroundColor Gray
        Write-Host ("{0,-12}" -f $st) -NoNewline -ForegroundColor $color
        Write-Host (" {0}" -f $gate.Branch) -ForegroundColor DarkGray
    }
    Write-Host ""
}

# ── Gate Runner ──────────────────────────────────────────────

function Assert-PreviousGateComplete($gateNum) {
    if ($gateNum -le 1) { return }
    $prevStatus = Get-GateStatus ($gateNum - 1)
    $st = if ($prevStatus -is [hashtable]) { $prevStatus.status } else { $prevStatus }
    if ($st -ne "COMPLETE") {
        Write-Fail "Gate $($gateNum - 1) is not COMPLETE (status: $st)"
        Write-Fail "You must complete Gate $($gateNum - 1) before opening Gate $gateNum."
        Write-Fail "Run: .\Run-Gate.ps1 -Gate $($gateNum - 1)"
        exit 1
    }
    Write-OK "Gate $($gateNum - 1) is COMPLETE — proceeding to Gate $gateNum."
}

function Run-Gate($gateNum) {
    $gate = $GATES[$gateNum]
    if (-not $gate) {
        Write-Fail "Unknown gate number: $gateNum"
        exit 1
    }

    Write-Header "GATE $gateNum — $($gate.Name.ToUpper())"
    Write-Info "Branch  : $($gate.Branch)"
    Write-Info "DryRun  : $DryRun"
    Write-Info "Date    : $(Get-Date -Format 'yyyy-MM-dd HH:mm')"

    if ($DryRun) {
        Write-Dry "DRY RUN MODE — no files will be modified, no commits will be made."
    }

    # Enforce gate ordering
    Assert-PreviousGateComplete $gateNum

    # Check current gate status
    $currentStatus = Get-GateStatus $gateNum
    $st = if ($currentStatus -is [hashtable]) { $currentStatus.status } else { $currentStatus }
    if ($st -eq "COMPLETE") {
        Write-OK "Gate $gateNum is already COMPLETE."
        $ans = Approve "Gate $gateNum is already closed. Re-open it and run again?"
        if ($ans -ne "YES") { return }
    }

    # Branch setup
    Set-Location $REPO
    $currentBranch = git branch --show-current
    Write-Info "Current branch: $currentBranch"

    if ($currentBranch -ne $gate.Branch) {
        $branchExists = git branch --list $gate.Branch
        if ($branchExists) {
            $ans = Approve "Switch to existing branch: $($gate.Branch)?"
            if ($ans -eq "ABORT") { exit 1 }
            if (-not $DryRun -and $ans -eq "YES") { git checkout $gate.Branch }
        } else {
            $ans = Approve "Create new branch: $($gate.Branch) from $currentBranch?"
            if ($ans -eq "ABORT") { exit 1 }
            if (-not $DryRun -and $ans -eq "YES") { git checkout -b $gate.Branch }
        }
    }

    # Mark gate as OPEN
    if (-not $DryRun) { Set-GateStatus $gateNum "OPEN" "Started $(Get-Date -Format 'yyyy-MM-dd')" }

    # Run deliverables
    $deliverables = $GATE_DELIVERABLES[$gateNum]
    if (-not $deliverables) {
        Write-Warn "No automated deliverables defined for Gate $gateNum."
        Write-Warn "Use Claude Code for manual gate work: cd $REPO && claude"

        $ans = Approve "Mark Gate $gateNum as COMPLETE manually?"
        if ($ans -eq "YES" -and -not $DryRun) {
            Set-GateStatus $gateNum "COMPLETE" "Manually closed $(Get-Date -Format 'yyyy-MM-dd')"
            Write-OK "Gate $gateNum marked COMPLETE."
        }
        return
    }

    Write-Host ""
    Write-Host "  Gate $gateNum Deliverables:" -ForegroundColor White
    foreach ($d in $deliverables) {
        $riskColor = switch ($d.Risk) {
            "CRITICAL" { "Red" }
            "HIGH"     { "DarkYellow" }
            "MEDIUM"   { "Yellow" }
            default    { "Gray" }
        }
        Write-Host ("  {0}  [{1,-8}]  {2}" -f $d.ID, $d.Risk, $d.Title) -ForegroundColor White
    }

    Write-Host ""
    $ans = Approve "Run all Gate $gateNum deliverables with individual approval checkpoints?"
    if ($ans -eq "ABORT") { Write-Fail "Aborted."; exit 1 }
    if ($ans -ne "YES") {
        Write-Warn "Gate $gateNum not executed. Status remains OPEN."
        return
    }

    # Execute each deliverable
    $completedCount = 0
    foreach ($d in $deliverables) {
        Write-Header "$($d.ID) — $($d.Title)"
        Write-Info "Risk: $($d.Risk)"

        $scriptPath = Join-Path $PSScriptRoot $d.Script
        if (Test-Path $scriptPath) {
            Write-Info "Script: $scriptPath"
            $dAns = Approve "Run $($d.ID): $($d.Title)?"
            if ($dAns -eq "ABORT") { Write-Fail "Aborted during $($d.ID)."; exit 1 }
            if ($dAns -eq "YES") {
                if (-not $DryRun) {
                    & $scriptPath
                    if ($LASTEXITCODE -eq 0) {
                        Write-OK "$($d.ID) completed."
                        $completedCount++
                    } else {
                        Write-Fail "$($d.ID) failed with exit code $LASTEXITCODE"
                        $ans2 = Approve "Continue to next deliverable despite failure?"
                        if ($ans2 -ne "YES") { exit 1 }
                    }
                } else {
                    Write-Dry "Would execute: $scriptPath"
                    $completedCount++
                }
            } else {
                Write-Warn "$($d.ID) skipped."
            }
        } else {
            Write-Warn "Script not found: $scriptPath"
            Write-Warn "This deliverable requires manual execution via Claude Code."
            Write-Info "Run: cd $REPO && claude"
            Write-Info "Then ask Claude to implement: $($d.Title)"
            $dAns = Approve "Mark $($d.ID) as complete after manual execution?"
            if ($dAns -eq "YES") { $completedCount++ }
        }
    }

    # Gate close check
    Write-Header "GATE $gateNum CLOSE CHECK"
    Write-Info "Deliverables completed: $completedCount / $($deliverables.Count)"

    if ($completedCount -eq $deliverables.Count) {
        Write-OK "All deliverables complete."

        # Git push prompt
        Write-Step "Commits on this branch:"
        git log --oneline "origin/main..$($gate.Branch)" 2>$null

        $pushAns = Approve "Push branch '$($gate.Branch)' to origin and open PR?"
        if ($pushAns -eq "YES" -and -not $DryRun) {
            git push --set-upstream origin $gate.Branch
            if ($LASTEXITCODE -eq 0) {
                Write-OK "Branch pushed. Open a PR: $($gate.Branch) -> main"
            }
        }

        $closeAns = Approve "Mark Gate $gateNum as COMPLETE? (Only after PR is merged)"
        if ($closeAns -eq "YES" -and -not $DryRun) {
            Set-GateStatus $gateNum "COMPLETE" "Closed $(Get-Date -Format 'yyyy-MM-dd'). All $($deliverables.Count) deliverables complete."
            Write-OK "Gate $gateNum marked COMPLETE."
            Write-Host ""
            Write-Host "  NEXT: Gate $($gateNum + 1) — $($GATES[$gateNum + 1].Name)" -ForegroundColor Cyan
            Write-Host "  Run:  .\Run-Gate.ps1 -Gate $($gateNum + 1)" -ForegroundColor Cyan
        }
    } else {
        Write-Warn "Gate $gateNum not fully complete: $completedCount/$($deliverables.Count) deliverables done."
        Write-Warn "Gate $gateNum remains OPEN. Complete remaining deliverables before closing."
        if (-not $DryRun) {
            Set-GateStatus $gateNum "OPEN" "In progress — $completedCount/$($deliverables.Count) deliverables $(Get-Date -Format 'yyyy-MM-dd')"
        }
    }
}

# ── Entry Point ──────────────────────────────────────────────

if (-not (Test-Path $REPO)) {
    Write-Fail "Repo not found at $REPO"
    exit 1
}

if ($Status) {
    Show-AllGateStatus
    exit 0
}

if ($Gate -eq 0) {
    Write-Header "GLOBAL WAKILI — GATE RUNNER"
    Write-Info "Usage:"
    Write-Info "  .\Run-Gate.ps1 -Status              # Show all gate statuses"
    Write-Info "  .\Run-Gate.ps1 -Gate 2              # Run Gate 2"
    Write-Info "  .\Run-Gate.ps1 -Gate 2 -DryRun      # Preview Gate 2 without changes"
    Write-Host ""
    Show-AllGateStatus
    exit 0
}

Run-Gate $Gate
