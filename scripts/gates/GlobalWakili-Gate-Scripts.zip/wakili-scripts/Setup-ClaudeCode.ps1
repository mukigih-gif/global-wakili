# ============================================================
# GLOBAL WAKILI — Claude Code CLI Setup
# Installs Claude Code, configures it for the repo, and
# creates the project memory file Claude Code will use.
# ============================================================

$REPO = "C:\Projects\global-wakili"

function Write-Header($text) {
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  $text" -ForegroundColor Cyan
    Write-Host "================================================================" -ForegroundColor Cyan
}
function Write-OK($text)   { Write-Host "  [OK] $text" -ForegroundColor Green }
function Write-Warn($text) { Write-Host "  [WARN] $text" -ForegroundColor DarkYellow }
function Write-Fail($text) { Write-Host "  [FAIL] $text" -ForegroundColor Red }
function Write-Info($text) { Write-Host "  $text" -ForegroundColor Gray }
function Write-Step($text) { Write-Host "  >> $text" -ForegroundColor Yellow }

function Approve($prompt) {
    Write-Host ""
    Write-Host "  APPROVAL REQUIRED" -ForegroundColor Magenta
    Write-Host "  $prompt" -ForegroundColor White
    Write-Host "  Type YES to proceed, NO to skip: " -ForegroundColor Magenta -NoNewline
    $ans = Read-Host
    return $ans.Trim().ToUpper()
}

Write-Header "GLOBAL WAKILI — Claude Code CLI Setup"

# ── Step 1: Check Node.js ────────────────────────────────────
Write-Step "Checking Node.js version..."
$nodeVersion = node --version 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Fail "Node.js not found. Install from https://nodejs.org (v18+)"
    exit 1
}
Write-OK "Node.js: $nodeVersion"

# ── Step 2: Install Claude Code ─────────────────────────────
Write-Header "Step 1 — Install Claude Code CLI"
Write-Info "Claude Code is Anthropic's official CLI for agentic coding."
Write-Info "It will be installed globally via npm."

$claudeCheck = Get-Command claude -ErrorAction SilentlyContinue
if ($claudeCheck) {
    $claudeVersion = claude --version 2>&1
    Write-OK "Claude Code already installed: $claudeVersion"
} else {
    $ans = Approve "Install Claude Code CLI globally? (npm install -g @anthropic-ai/claude-code)"
    if ($ans -eq "YES") {
        npm install -g @anthropic-ai/claude-code
        if ($LASTEXITCODE -ne 0) {
            Write-Fail "Installation failed. Try running PowerShell as Administrator."
            exit 1
        }
        Write-OK "Claude Code installed."
    } else {
        Write-Warn "Skipped. You can install manually: npm install -g @anthropic-ai/claude-code"
    }
}

# ── Step 3: Authenticate ─────────────────────────────────────
Write-Header "Step 2 — Authenticate Claude Code"
Write-Info "Claude Code needs to authenticate with your Anthropic account."
Write-Info "This opens a browser window for OAuth login."

$ans = Approve "Run 'claude login' to authenticate now?"
if ($ans -eq "YES") {
    Set-Location $REPO
    claude login
    Write-OK "Authentication complete."
} else {
    Write-Warn "Skipped. Run 'claude login' manually before using Claude Code."
}

# ── Step 4: Create CLAUDE.md project memory ──────────────────
Write-Header "Step 3 — Create CLAUDE.md Project Memory"
Write-Info "CLAUDE.md is the file Claude Code reads at startup for every session."
Write-Info "It contains Global Wakili's architecture, principles, and current status."

$claudeMd = Join-Path $REPO "CLAUDE.md"

$ans = Approve "Create CLAUDE.md at repo root with Global Wakili project memory?"
if ($ans -eq "YES") {
    @'
# GLOBAL WAKILI — Claude Code Project Memory

## Project Identity

Global Wakili Legal Enterprise is a production-grade multi-tenant legal ERP
and legal accounting platform built for law firms in Kenya.

**Stack:** Node.js + Express + TypeScript + Prisma + PostgreSQL + Redis + MinIO
**Workspace:** pnpm monorepo (apps/api, apps/web, packages/database, packages/core, packages/common)
**Primary jurisdiction:** Kenya (Kenya Data Protection Act, KRA eTIMS, Trust Accounting)

---

## Core Principles (NEVER violate these)

1. Tenant isolation before features
2. Accounting integrity before convenience
3. Auditability before automation
4. Security before performance
5. Preserve architecture before redesign
6. Complete unfinished work before introducing new modules
7. Finish backend closure before frontend expansion
8. Finish provisioning before integrations
9. Finish integrations before deployment
10. Production readiness before go-live

---

## Operating Rules

### Approval Mode
- ALWAYS use Plan Mode: Analyze → Propose → Wait for approval → Execute
- NEVER modify files autonomously without showing the plan first
- NEVER commit automatically — always show git status + impacted files + risks + test plan

### Model Selection
- Use **Opus** for: architecture, schema, security, finance, trust accounting
- Use **Sonnet** for: large refactors, bulk search, documentation, memory

### Repository Preservation
- NEVER replace a subsystem unless verified architectural failure exists
- Prefer enhancement over replacement
- Prefer extension over refactoring
- Preserve existing business logic

### Multi-Tenant Discipline
- Every query touching tenant data MUST include explicit tenantId validation
- TENANT_SCOPED_MODELS set in packages/database/src/tenant-extension.ts is authoritative
- Zero tenant leakage is acceptable

### Financial Discipline
- Do NOT simplify accounting logic
- Do NOT redesign reconciliation flows without proof
- Maintain all accounting invariants (debit=credit, period locking, idempotency)

### Security Discipline
- Always verify: authentication, authorization, tenant boundaries, audit trails, signed URLs, secrets handling

### Git Discipline
- Never commit without showing: git status + impacted files + risks + test plan
- All gate work happens on feature branches, never directly on main

---

## Architecture

### Tenant Extension
- File: packages/database/src/tenant-extension.ts
- 100 models in TENANT_SCOPED_MODELS
- All reads auto-inject AND: [{ tenantId }]
- All writes auto-inject tenantId
- Unsafe unique operations blocked

### Audit Chain
- Files: apps/api/src/utils/audit-hash.ts, audit-logger.ts
- SHA-256 hash chaining with previousHash per entry
- AuditLog: tenant-level | GlobalAuditLog: platform-level
- KNOWN ISSUE: race condition on previousHash fetch (Gate 2 fix pending)

### Trust Accounting
- Status: HARDENED (commit 76f8ecf)
- assertSufficientBalance enforced before every debit
- Three-way reconciliation implemented
- All trust queries include explicit tenantId

### Finance
- Full double-entry ledger: COA, journals, balances, period close, reconciliation
- IdempotencyService prevents duplicate journal postings
- KNOWN ISSUE: duplicate service files pending consolidation (Gate 1 fix)
- eTIMS: stub only (Gate 11 work)

---

## Current Gate Status

| Gate | Name | Status |
|------|------|--------|
| Gate 1 | Repository Assessment | COMPLETE |
| Gate 2 | Schema Verification | OPEN — fixes in progress |
| Gates 3–16 | See GATE_1_GATE_2_TRANSITION_REPORT.docx | PENDING |

### Open Workstreams
- WIP-001: Control Plane Provisioning (auto-provisioning not wired)
- WIP-002: Notification Platform (providers simulated)
- WIP-003: Document Platform (cloud adapters missing)
- WIP-004: Passive Time Capture (not started)
- WIP-005: AI Legal Operations (fail-closed, no LLM provider)
- WIP-006: External Integrations (stubbed)
- WIP-007: Frontend Completion (login page only)
- WIP-008: Queue Worker (dispatch stub)
- WIP-009: Audit Chain Hardening (race condition fix pending)
- WIP-010: Testing Matrix (zero tests)
- WIP-011: CI/CD Pipeline (minimal)
- WIP-012: Infrastructure/DevOps (not started)
- WIP-013: Documentation (minimal)

### Completion Estimates
- Backend: ~72% | Frontend: ~5% | Tests: 0% | Overall: ~52%

---

## Governance Documents
All gate reports are in: docs/governance/
- GATE_1_FINAL_ASSESSMENT.md
- GATE_2_MIGRATIONS_PENDING.md
- GATE_1_GATE_2_TRANSITION_REPORT.docx

---

## Known Issues (fix before proceeding)
1. GlobalAuditLog.hash missing @unique constraint
2. AuditLog previousHash fetch has race condition under concurrency
3. 278 TypeScript `any` types in tenant-scoped paths
4. TimerDbClient = any in TimerService.ts
5. Session model lacks tenantId
6. financedashboard.tsx was in backend module (moved in Gate 1 fixes)
7. Duplicate finance service files (consolidation in Gate 1 fixes)

---

*Last updated: Gate 1 complete. Gate 2 branch: gate-2/schema-verification*
'@ | Set-Content $claudeMd -Encoding UTF8

    Write-OK "CLAUDE.md created at: $claudeMd"

    # Add to git
    Set-Location $REPO
    git add CLAUDE.md
    Write-Step "CLAUDE.md staged. Review it, then commit with:"
    Write-Info "  git commit -m 'chore: add CLAUDE.md project memory for Claude Code'"
} else {
    Write-Warn "CLAUDE.md creation skipped."
}

# ── Step 5: Configure approval mode ─────────────────────────
Write-Header "Step 4 — Configure Claude Code Settings"
Write-Info "Setting Claude Code to Plan Mode (requires approval before any file changes)."

$claudeConfigDir = Join-Path $env:APPDATA "claude-code"
if (-not (Test-Path $claudeConfigDir)) {
    New-Item -ItemType Directory -Force -Path $claudeConfigDir | Out-Null
}

$settingsFile = Join-Path $claudeConfigDir "settings.json"
$settings = @{
    approvalMode = "plan"
    model = "claude-opus-4-6"
    projectMemoryFile = "CLAUDE.md"
    autoCommit = $false
    telemetry = $false
} | ConvertTo-Json

$ans = Approve "Write Claude Code settings (Plan Mode + Opus model + no auto-commit)?"
if ($ans -eq "YES") {
    $settings | Set-Content $settingsFile -Encoding UTF8
    Write-OK "Settings written to: $settingsFile"
} else {
    Write-Warn "Settings skipped. Claude Code will use defaults."
}

# ── Step 6: Test launch ──────────────────────────────────────
Write-Header "Step 5 — Test Claude Code in Repo"
Write-Info "This will launch Claude Code in your repo directory."
Write-Info "Claude will read CLAUDE.md and be ready for Gate 2 work."
Write-Info "Type 'exit' inside Claude Code to return to PowerShell."

$ans = Approve "Launch Claude Code now in $REPO ?"
if ($ans -eq "YES") {
    Set-Location $REPO
    claude
} else {
    Write-Warn "Skipped. To launch manually:"
    Write-Info "  cd $REPO"
    Write-Info "  claude"
}

Write-Header "SETUP COMPLETE"
Write-Info "Claude Code is configured for Global Wakili."
Write-Info ""
Write-Info "To start a Gate 2 session:"
Write-Info "  cd C:\Projects\global-wakili"
Write-Info "  claude"
Write-Info ""
Write-Info "Claude will read CLAUDE.md automatically and know the full project context."
