# ============================================================
# GLOBAL WAKILI — GATE 1 FIXES
# Gate 1 fixes must be complete and pushed before Gate 2 opens.
#
# RULES:
#  - Script NEVER commits automatically
#  - Every fix shows: what changes, which files, risks, test plan
#  - You approve each fix before it executes
#  - Git push only happens after explicit final approval
# ============================================================

$REPO = "C:\Projects\global-wakili"
$BRANCH = "gate-1/fixes"
$SCRIPT_VERSION = "1.0.0"

# ── Helpers ──────────────────────────────────────────────────

function Write-Header($text) {
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  $text" -ForegroundColor Cyan
    Write-Host "================================================================" -ForegroundColor Cyan
}

function Write-Step($text) {
    Write-Host ""
    Write-Host "  >> $text" -ForegroundColor Yellow
}

function Write-OK($text) {
    Write-Host "  [OK] $text" -ForegroundColor Green
}

function Write-Warn($text) {
    Write-Host "  [WARN] $text" -ForegroundColor DarkYellow
}

function Write-Fail($text) {
    Write-Host "  [FAIL] $text" -ForegroundColor Red
}

function Write-Info($text) {
    Write-Host "  $text" -ForegroundColor Gray
}

function Approve($prompt) {
    Write-Host ""
    Write-Host "  APPROVAL REQUIRED" -ForegroundColor Magenta
    Write-Host "  $prompt" -ForegroundColor White
    Write-Host "  Type YES to proceed, SKIP to skip this fix, ABORT to stop all: " -ForegroundColor Magenta -NoNewline
    $ans = Read-Host
    return $ans.Trim().ToUpper()
}

function Show-GitStatus {
    Write-Step "Current git status:"
    git -C $REPO status --short
    Write-Host ""
    Write-Step "Files staged:"
    git -C $REPO diff --name-only --cached
}

function Assert-RepoClean {
    $dirty = git -C $REPO status --porcelain
    if ($dirty) {
        Write-Warn "Repo has uncommitted changes. Showing status:"
        git -C $REPO status --short
        $ans = Approve "Repo is not clean. Continue anyway? (YES/ABORT)"
        if ($ans -ne "YES") { exit 1 }
    }
}

# ── Preflight ────────────────────────────────────────────────

Write-Header "GLOBAL WAKILI — GATE 1 FIX SCRIPT v$SCRIPT_VERSION"
Write-Info "Repo    : $REPO"
Write-Info "Branch  : $BRANCH"
Write-Info "Date    : $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
Write-Info ""
Write-Info "This script applies all 7 Gate 1 fixes in order."
Write-Info "Each fix requires your approval before execution."
Write-Info "Nothing is committed or pushed without explicit approval."

if (-not (Test-Path $REPO)) {
    Write-Fail "Repo not found at $REPO — aborting."
    exit 1
}

Set-Location $REPO

# Verify git repo
git -C $REPO rev-parse --git-dir | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Fail "Not a git repository. Aborting."
    exit 1
}

Write-OK "Repo verified."

# Check current branch
$currentBranch = git -C $REPO branch --show-current
Write-Info "Current branch: $currentBranch"

# Create/switch to gate-1/fixes branch
$branchExists = git -C $REPO branch --list $BRANCH
if ($branchExists) {
    Write-Info "Branch $BRANCH already exists."
    $ans = Approve "Switch to existing branch $BRANCH? (YES/ABORT)"
    if ($ans -ne "YES") { exit 1 }
    git -C $REPO checkout $BRANCH
} else {
    $ans = Approve "Create and switch to new branch: $BRANCH (from $currentBranch)?"
    if ($ans -ne "YES") { exit 1 }
    git -C $REPO checkout -b $BRANCH
}

Write-OK "On branch: $(git -C $REPO branch --show-current)"

# ── FIX-01: Create /docs/governance/ and save Gate 1 report ─

Write-Header "FIX-01 — Create /docs/governance/ directory"
Write-Info "What changes  : Creates docs/governance/ directory with a .gitkeep"
Write-Info "                and a placeholder GATE_1_FINAL_ASSESSMENT.md"
Write-Info "Files impacted: docs/governance/.gitkeep"
Write-Info "                docs/governance/GATE_1_FINAL_ASSESSMENT.md"
Write-Info "Risk          : LOW — new files only, nothing modified"
Write-Info "Test plan     : Verify directory exists and files are tracked by git"

$ans = Approve "Apply FIX-01 — Create /docs/governance/ ?"
if ($ans -eq "ABORT") { Write-Fail "Aborted by user."; exit 1 }
if ($ans -eq "YES") {
    $docsPath = Join-Path $REPO "docs\governance"
    New-Item -ItemType Directory -Force -Path $docsPath | Out-Null

    # .gitkeep
    $gitkeep = Join-Path $docsPath ".gitkeep"
    if (-not (Test-Path $gitkeep)) { New-Item -ItemType File -Path $gitkeep | Out-Null }

    # Gate 1 placeholder — user must paste full content
    $gate1path = Join-Path $docsPath "GATE_1_FINAL_ASSESSMENT.md"
    if (-not (Test-Path $gate1path)) {
        @"
# GATE 1 — FINAL ASSESSMENT REPORT
# Global Wakili Legal Enterprise
# Date: $(Get-Date -Format 'yyyy-MM-dd')
# Status: COMPLETE
#
# NOTE: Paste the full Gate 1 report content here from the
# GATE_1_GATE_2_TRANSITION_REPORT.docx before committing.
# This file must contain the complete untruncated assessment.
"@ | Set-Content $gate1path -Encoding UTF8
        Write-Warn "GATE_1_FINAL_ASSESSMENT.md created as placeholder."
        Write-Warn "ACTION REQUIRED: Paste full Gate 1 report content into:"
        Write-Warn "  $gate1path"
        Write-Warn "Then run this script again to continue."
    } else {
        Write-OK "GATE_1_FINAL_ASSESSMENT.md already exists."
    }

    git -C $REPO add docs/
    Show-GitStatus

    $ans2 = Approve "Commit FIX-01 — 'chore: create docs/governance directory and Gate 1 report placeholder'?"
    if ($ans2 -eq "YES") {
        git -C $REPO commit -m "chore: create docs/governance directory and Gate 1 report placeholder"
        Write-OK "FIX-01 committed."
    } else {
        git -C $REPO reset HEAD docs/
        Write-Warn "FIX-01 staged but NOT committed — reset to unstaged."
    }
} else {
    Write-Warn "FIX-01 skipped."
}

# ── FIX-02: Replace prisma db push with migrate deploy in CI ─

Write-Header "FIX-02 [CRITICAL] — Replace prisma db push in CI"
Write-Info "What changes  : .github/workflows/ci.yml"
Write-Info "                'prisma db push' -> 'prisma migrate deploy'"
Write-Info "Files impacted: .github/workflows/ci.yml"
Write-Info "Risk          : MEDIUM — changes CI behaviour. prisma migrate deploy"
Write-Info "                is safe and idempotent. prisma db push is destructive."
Write-Info "Test plan     : CI pipeline must pass on this branch after change."

$ciFile = Join-Path $REPO ".github\workflows\ci.yml"
if (-not (Test-Path $ciFile)) {
    Write-Warn "ci.yml not found at expected path: $ciFile"
    Write-Warn "Searching for CI files..."
    Get-ChildItem -Path (Join-Path $REPO ".github") -Recurse -Filter "*.yml" | ForEach-Object { Write-Info $_.FullName }
} else {
    $ciContent = Get-Content $ciFile -Raw
    if ($ciContent -match "prisma db push") {
        Write-Warn "CONFIRMED: 'prisma db push' found in ci.yml — this is a data-loss risk."
        $ans = Approve "Apply FIX-02 — Replace 'prisma db push' with 'prisma migrate deploy'?"
        if ($ans -eq "ABORT") { Write-Fail "Aborted."; exit 1 }
        if ($ans -eq "YES") {
            # Replace db push with migrate deploy
            $newContent = $ciContent -replace "prisma db push", "prisma migrate deploy"
            # Also add prisma generate if not present after migrate
            if ($newContent -notmatch "prisma generate") {
                $newContent = $newContent -replace "(prisma migrate deploy)", '$1`n      - run: npx prisma generate'
            }
            Set-Content $ciFile $newContent -Encoding UTF8
            Write-OK "ci.yml updated."
            git -C $REPO add .github/workflows/ci.yml
            Show-GitStatus

            $ans2 = Approve "Commit FIX-02 — 'fix(ci): replace prisma db push with prisma migrate deploy'?"
            if ($ans2 -eq "YES") {
                git -C $REPO commit -m "fix(ci): replace prisma db push with prisma migrate deploy`n`nCRITICAL: prisma db push bypasses migration history and can drop`ncolumns silently. prisma migrate deploy is safe and idempotent."
                Write-OK "FIX-02 committed."
            } else {
                git -C $REPO reset HEAD .github/workflows/ci.yml
                Write-Warn "FIX-02 NOT committed — reset."
            }
        } else {
            Write-Warn "FIX-02 skipped."
        }
    } else {
        Write-OK "FIX-02 — 'prisma db push' NOT found in ci.yml. Already clean."
    }
}

# ── FIX-03: Create .env.example ──────────────────────────────

Write-Header "FIX-03 [HIGH] — Create .env.example"
Write-Info "What changes  : Creates .env.example at repo root"
Write-Info "Files impacted: .env.example (new file)"
Write-Info "Risk          : LOW — documentation only, no secrets, no logic change"
Write-Info "Test plan     : CI existence check in main.yml must pass"

$envExample = Join-Path $REPO ".env.example"
if (Test-Path $envExample) {
    Write-OK ".env.example already exists. Skipping FIX-03."
} else {
    $ans = Approve "Apply FIX-03 — Create .env.example with all required variables?"
    if ($ans -eq "ABORT") { Write-Fail "Aborted."; exit 1 }
    if ($ans -eq "YES") {
        # Scan for all process.env references in the codebase
        Write-Step "Scanning codebase for process.env references..."
        $envVars = @()
        Get-ChildItem -Path (Join-Path $REPO "apps") -Recurse -Include "*.ts" |
            Select-String -Pattern 'process\.env\.(\w+)' |
            ForEach-Object { $_.Matches.Groups[1].Value } |
            Sort-Object -Unique |
            ForEach-Object { $envVars += $_ }
        Get-ChildItem -Path (Join-Path $REPO "packages") -Recurse -Include "*.ts" |
            Select-String -Pattern 'process\.env\.(\w+)' |
            ForEach-Object { $_.Matches.Groups[1].Value } |
            Sort-Object -Unique |
            ForEach-Object { $envVars += $_ }
        $envVars = $envVars | Sort-Object -Unique

        Write-Info "Found $($envVars.Count) environment variables in codebase."

        # Build .env.example content
        $lines = @()
        $lines += "# ============================================================"
        $lines += "# GLOBAL WAKILI — Environment Variables"
        $lines += "# Copy this file to .env and fill in real values"
        $lines += "# NEVER commit .env with real secrets"
        $lines += "# ============================================================"
        $lines += ""
        $lines += "# Database"
        $lines += "DATABASE_URL=postgresql://user:password@localhost:5432/global_wakili"
        $lines += "DIRECT_URL=postgresql://user:password@localhost:5432/global_wakili"
        $lines += ""
        $lines += "# Redis"
        $lines += "REDIS_URL=redis://localhost:6379"
        $lines += ""
        $lines += "# MinIO (Object Storage)"
        $lines += "MINIO_ENDPOINT=localhost"
        $lines += "MINIO_PORT=9000"
        $lines += "MINIO_ACCESS_KEY=minioadmin"
        $lines += "MINIO_SECRET_KEY=minioadmin"
        $lines += "MINIO_BUCKET_NAME=global-wakili"
        $lines += "MINIO_USE_SSL=false"
        $lines += ""
        $lines += "# JWT"
        $lines += "JWT_SECRET=replace-with-256-bit-secret"
        $lines += "JWT_REFRESH_SECRET=replace-with-refresh-secret"
        $lines += "JWT_EXPIRES_IN=15m"
        $lines += "JWT_REFRESH_EXPIRES_IN=7d"
        $lines += ""
        $lines += "# App"
        $lines += "NODE_ENV=development"
        $lines += "PORT=3000"
        $lines += "API_URL=http://localhost:3000"
        $lines += ""
        $lines += "# Platform Admin"
        $lines += "PLATFORM_ADMIN_SECRET=replace-with-platform-admin-secret"
        $lines += ""
        $lines += "# KRA eTIMS (Kenya Revenue Authority)"
        $lines += "ETIMS_BASE_URL=https://etims-api.kra.go.ke"
        $lines += "ETIMS_API_KEY=replace-with-etims-api-key"
        $lines += ""
        $lines += "# M-PESA (Safaricom)"
        $lines += "MPESA_CONSUMER_KEY=replace-with-mpesa-key"
        $lines += "MPESA_CONSUMER_SECRET=replace-with-mpesa-secret"
        $lines += "MPESA_SHORTCODE=replace-with-shortcode"
        $lines += "MPESA_PASSKEY=replace-with-passkey"
        $lines += "MPESA_CALLBACK_URL=https://yourdomain.com/api/payments/mpesa/callback"
        $lines += ""
        $lines += "# Email (SMTP)"
        $lines += "SMTP_HOST=smtp.example.com"
        $lines += "SMTP_PORT=587"
        $lines += "SMTP_USER=noreply@example.com"
        $lines += "SMTP_PASS=replace-with-smtp-password"
        $lines += "SMTP_FROM=Global Wakili <noreply@example.com>"
        $lines += ""
        $lines += "# SMS (Africa's Talking)"
        $lines += "AT_API_KEY=replace-with-africastalking-key"
        $lines += "AT_USERNAME=replace-with-username"
        $lines += ""
        $lines += "# AI Provider"
        $lines += "ANTHROPIC_API_KEY=replace-with-anthropic-key"
        $lines += "OPENAI_API_KEY=replace-with-openai-key"
        $lines += ""
        $lines += "# Frontend"
        $lines += "NEXT_PUBLIC_API_URL=http://localhost:3000"
        $lines += "NEXT_PUBLIC_WS_URL=ws://localhost:3000"
        $lines += ""

        # Append any discovered vars not already covered
        $covered = @("DATABASE_URL","DIRECT_URL","REDIS_URL","MINIO_ENDPOINT","MINIO_PORT",
                     "MINIO_ACCESS_KEY","MINIO_SECRET_KEY","JWT_SECRET","JWT_REFRESH_SECRET",
                     "NODE_ENV","PORT","PLATFORM_ADMIN_SECRET")
        $extra = $envVars | Where-Object { $covered -notcontains $_ }
        if ($extra.Count -gt 0) {
            $lines += "# Additional variables discovered in codebase"
            $extra | ForEach-Object { $lines += "$_=replace-with-value" }
        }

        $lines | Set-Content $envExample -Encoding UTF8
        Write-OK ".env.example created with $($lines.Count) lines."

        git -C $REPO add .env.example
        Show-GitStatus

        $ans2 = Approve "Commit FIX-03 — 'chore: add .env.example with all required environment variables'?"
        if ($ans2 -eq "YES") {
            git -C $REPO commit -m "chore: add .env.example with all required environment variables`n`nDocuments all process.env references found in codebase.`nRequired by main.yml CI existence check."
            Write-OK "FIX-03 committed."
        } else {
            git -C $REPO reset HEAD .env.example
            Write-Warn "FIX-03 NOT committed — reset."
        }
    } else {
        Write-Warn "FIX-03 skipped."
    }
}

# ── FIX-04: Move financedashboard.tsx to frontend ────────────

Write-Header "FIX-04 [HIGH] — Move financedashboard.tsx to frontend"
Write-Info "What changes  : Moves apps/api/src/modules/finance/financedashboard.tsx"
Write-Info "                to apps/web/src/modules/finance/financedashboard.tsx"
Write-Info "Files impacted: apps/api/src/modules/finance/financedashboard.tsx (deleted)"
Write-Info "                apps/web/src/modules/finance/financedashboard.tsx (created)"
Write-Info "Risk          : LOW — file move only. Run tsc --noEmit after to verify."
Write-Info "Test plan     : tsc --noEmit in apps/api must pass after move."

$srcTsx = Join-Path $REPO "apps\api\src\modules\finance\financedashboard.tsx"
if (-not (Test-Path $srcTsx)) {
    Write-OK "financedashboard.tsx not found in backend — already moved or renamed."
} else {
    $ans = Approve "Apply FIX-04 — Move financedashboard.tsx from backend to frontend?"
    if ($ans -eq "ABORT") { Write-Fail "Aborted."; exit 1 }
    if ($ans -eq "YES") {
        $destDir = Join-Path $REPO "apps\web\src\modules\finance"
        New-Item -ItemType Directory -Force -Path $destDir | Out-Null
        $destTsx = Join-Path $destDir "financedashboard.tsx"
        Copy-Item $srcTsx $destTsx
        Remove-Item $srcTsx
        Write-OK "Moved to: $destTsx"

        git -C $REPO add apps/web/src/modules/finance/financedashboard.tsx
        git -C $REPO add apps/api/src/modules/finance/financedashboard.tsx
        Show-GitStatus

        Write-Step "Running tsc --noEmit on apps/api to verify no broken imports..."
        Set-Location (Join-Path $REPO "apps\api")
        $tscResult = npx tsc --noEmit 2>&1
        Set-Location $REPO
        if ($LASTEXITCODE -eq 0) {
            Write-OK "tsc --noEmit passed — no broken imports."
        } else {
            Write-Warn "tsc --noEmit reported errors:"
            $tscResult | ForEach-Object { Write-Info $_ }
            Write-Warn "Review errors above before committing."
        }

        $ans2 = Approve "Commit FIX-04 — 'fix: move financedashboard.tsx from backend to frontend module'?"
        if ($ans2 -eq "YES") {
            git -C $REPO commit -m "fix: move financedashboard.tsx from backend to frontend module`n`nTSX React files must not live in the backend API module directory.`nMoved to apps/web/src/modules/finance/."
            Write-OK "FIX-04 committed."
        } else {
            git -C $REPO reset HEAD -- apps/
            Write-Warn "FIX-04 NOT committed — reset."
        }
    } else {
        Write-Warn "FIX-04 skipped."
    }
}

# ── FIX-05: Read startup-error.log ───────────────────────────

Write-Header "FIX-05 — Read and triage startup-error.log"
Write-Info "What changes  : Read-only diagnostic. No files modified."
Write-Info "Risk          : NONE"

$errLog = Join-Path $REPO "startup-error.log"
if (-not (Test-Path $errLog)) {
    Write-OK "startup-error.log not found — may have been resolved already."
} else {
    $size = (Get-Item $errLog).Length
    if ($size -eq 0) {
        Write-OK "startup-error.log is empty — no startup errors."
    } else {
        Write-Warn "startup-error.log is non-empty ($size bytes). Contents:"
        Write-Host "────────────────────────────────────────" -ForegroundColor DarkGray
        Get-Content $errLog | ForEach-Object { Write-Host "  $_" -ForegroundColor White }
        Write-Host "────────────────────────────────────────" -ForegroundColor DarkGray
        Write-Warn "ACTION REQUIRED: Review the errors above."
        Write-Warn "Common causes: missing .env, failed DB connection, broken import."
        $ans = Approve "After reviewing, clear startup-error.log? (YES = truncate it after fix, SKIP = leave as-is)"
        if ($ans -eq "YES") {
            Clear-Content $errLog
            Write-OK "startup-error.log cleared. Fix the root cause before running the server."
        }
    }
}

# ── FIX-06: Add GlobalAuditLog.hash @unique note ─────────────

Write-Header "FIX-06 — Document GlobalAuditLog.hash @unique as Gate 2 migration"
Write-Info "What changes  : Creates docs/governance/GATE_2_MIGRATIONS_PENDING.md"
Write-Info "                documenting the 2 schema migrations required in Gate 2"
Write-Info "Files impacted: docs/governance/GATE_2_MIGRATIONS_PENDING.md (new)"
Write-Info "Risk          : LOW — documentation only"
Write-Info "NOTE: Actual schema changes happen in Gate 2, not here."

$ans = Approve "Apply FIX-06 — Create Gate 2 pending migrations document?"
if ($ans -eq "ABORT") { Write-Fail "Aborted."; exit 1 }
if ($ans -eq "YES") {
    $migrationsDoc = Join-Path $REPO "docs\governance\GATE_2_MIGRATIONS_PENDING.md"
    @"
# GATE 2 — PENDING SCHEMA MIGRATIONS

These migrations are required in Gate 2 before schema verification closes.

## MIGRATION-01: GlobalAuditLog.hash @unique

**Priority:** HIGH
**Risk:** GlobalAuditLog currently has no uniqueness constraint on hash.
At platform level, two GlobalAuditLog entries with the same hash can exist,
breaking tamper-evidence at the control plane.

**Required change in schema.prisma:**
``````prisma
model GlobalAuditLog {
  hash String @unique   // ADD THIS
  // ... existing fields
}
``````

**Migration command:**
``````bash
npx prisma migrate dev --name add_global_audit_log_hash_unique
``````

---

## MIGRATION-02: AuditLog + GlobalAuditLog sequenceNumber

**Priority:** HIGH
**Risk:** Current audit chain uses findFirst({ orderBy: { createdAt: desc } })
to fetch previousHash. Two concurrent writes can read the same previousHash,
forking the chain and breaking tamper-evidence integrity.

**Required change in schema.prisma:**
``````prisma
model AuditLog {
  sequenceNumber BigInt @default(autoincrement())
  // ... existing fields
}

model GlobalAuditLog {
  sequenceNumber BigInt @default(autoincrement())
  // ... existing fields
}
``````

**Also update audit-hash.ts:** Change chain fetch to use
``ORDER BY sequenceNumber DESC`` instead of ``ORDER BY createdAt DESC``.

**Migration command:**
``````bash
npx prisma migrate dev --name add_audit_sequence_numbers
``````

---

Status: PENDING — Gate 2 implementation required.
Created: $(Get-Date -Format 'yyyy-MM-dd')
"@ | Set-Content $migrationsDoc -Encoding UTF8

    git -C $REPO add docs/governance/GATE_2_MIGRATIONS_PENDING.md
    Show-GitStatus

    $ans2 = Approve "Commit FIX-06 — 'docs: add Gate 2 pending migrations document'?"
    if ($ans2 -eq "YES") {
        git -C $REPO commit -m "docs: add Gate 2 pending migrations document`n`nDocuments GlobalAuditLog.hash @unique and audit sequenceNumber`nmigrations required before Gate 2 schema verification closes."
        Write-OK "FIX-06 committed."
    } else {
        git -C $REPO reset HEAD docs/governance/GATE_2_MIGRATIONS_PENDING.md
        Write-Warn "FIX-06 NOT committed — reset."
    }
} else {
    Write-Warn "FIX-06 skipped."
}

# ── Final: Git Push ──────────────────────────────────────────

Write-Header "FINAL STEP — Git Push"
Write-Info "Branch to push : $BRANCH"
Write-Info "Remote         : origin"
Write-Host ""
Write-Step "Summary of commits on this branch:"
git -C $REPO log --oneline origin/main..$BRANCH 2>$null
if ($LASTEXITCODE -ne 0) {
    git -C $REPO log --oneline -10
}

Write-Host ""
$ans = Approve "Push branch '$BRANCH' to origin? This will create a PR-ready branch."
if ($ans -eq "YES") {
    git -C $REPO push --set-upstream origin $BRANCH
    if ($LASTEXITCODE -eq 0) {
        Write-OK "Branch pushed to origin/$BRANCH"
        Write-Host ""
        Write-Host "  NEXT STEPS:" -ForegroundColor Cyan
        Write-Host "  1. Open a Pull Request: $BRANCH -> main" -ForegroundColor White
        Write-Host "  2. Review all changes in the PR diff" -ForegroundColor White
        Write-Host "  3. After PR is merged, run Gate2-Setup.ps1" -ForegroundColor White
    } else {
        Write-Fail "Push failed. Check your git remote and credentials."
    }
} else {
    Write-Warn "Push skipped. Run: git push --set-upstream origin $BRANCH when ready."
}

Write-Header "GATE 1 FIXES COMPLETE"
Write-Info "All applied fixes are committed to: $BRANCH"
Write-Info "Review the PR before merging to main."
Write-Info "Do NOT open Gate 2 until Gate 1 PR is merged."
